# 🌍 Weather Globe Dashboard

An interactive 3D weather dashboard with a rotating globe. Click any country to see live weather data and a 7-day forecast.

![Preview](https://img.shields.io/badge/status-live-success)
![API](https://img.shields.io/badge/API-OpenMeteo-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## Features

- 🌐 **Interactive 3D Globe** — Rotating Earth with country borders
- 🖱️ **Click any country** — Camera flies to it, weather panel slides in
- ☀️ **Live weather** — Temp, feels-like, humidity, wind, precipitation, pressure, UV index
- 📅 **7-day forecast** — Daily highs, lows, conditions, precipitation
- 🎨 **Stunning UI** — Dark theme, glassmorphism, smooth animations
- 🔁 **Auto-rotate** — Globe spins until you interact

## Tech Stack

| Layer | Technology |
|---|---|
| Backend | Django 5 + Django REST Framework |
| API | Open-Meteo (free, no API key) |
| Frontend | Globe.gl (Three.js), vanilla JS |
| Styling | CSS custom properties, glassmorphism |
| Data | Countries from Natural Earth GeoJSON |

## Quick Start

### Prerequisites
- Python 3.10+

### Setup

```bash
# 1. Create a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the server
python manage.py runserver 0.0.0.0:8080
```

### Open in browser
```
http://localhost:8080
```

> ⚠️ Some browsers auto-upgrade HTTP to HTTPS. If the globe doesn't load, try Firefox or incognito mode, or serve behind a reverse proxy with SSL.

## How It Works

1. **Globe** — Rendered in 3D using Three.js via Globe.gl with country polygons
2. **Click** — Clicking a country calculates its centroid, flies the camera there, and fetches weather
3. **Weather API** — Free [Open-Meteo API](https://open-meteo.com/) returns current + 7-day forecast
4. **Country data** — Served from Natural Earth's public GeoJSON (110m resolution)

## API Endpoints

| Endpoint | Description |
|---|---|
| `GET /` | Main dashboard page |
| `GET /api/countries/` | World countries GeoJSON |
| `GET /api/weather/?lat=...&lon=...&country=...` | Live weather data |

## Configuration

Local development works with zero setup. For deployment, copy `.env.example` to `.env` (or set these as real environment variables) and fill them in:

| Variable | Purpose | Default |
|---|---|---|
| `DJANGO_SECRET_KEY` | Django's cryptographic signing key | insecure dev key |
| `DJANGO_DEBUG` | Enables/disables debug mode | `True` |
| `DJANGO_ALLOWED_HOSTS` | Comma-separated list of allowed hostnames | `localhost,127.0.0.1` |

**Before deploying:** set `DJANGO_SECRET_KEY` to a real random value, set `DJANGO_DEBUG=False`, and set `DJANGO_ALLOWED_HOSTS` to your actual domain.

## Project Structure

```
weather_dashboard/
├── manage.py              # Django entry point
├── requirements.txt       # Python dependencies
├── README.md              # This file
├── .env.example           # Template for production environment variables
├── .gitignore
├── LICENSE
├── weather/               # Weather app (backend)
│   ├── views.py           # API views (weather + countries proxy)
│   ├── urls.py            # API route definitions
│   ├── models.py          # (extendable for history/favorites)
│   └── migrations/        # DB migrations
├── weather_dashboard/     # Django project config
│   ├── settings.py        # App settings
│   └── urls.py            # Root URL config
├── static/                # Frontend assets
│   ├── css/style.css      # All styling
│   └── js/app.js          # Globe + weather logic
└── templates/
    └── core/index.html    # Main page template
```

## License

MIT — free to use, modify, and share. Built with open-source libraries:
- [Globe.gl](https://globe.gl/)
- [Three.js](https://threejs.org/)
- [Open-Meteo](https://open-meteo.com/)
- [Natural Earth](https://www.naturalearthdata.com/)