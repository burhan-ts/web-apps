/* global Globe, THREE */

// === State ===
let globe = null;
let countriesGeoJSON = null;
let isUserInteracting = false;
let interactionTimeout = null;

// === DOM refs ===
const container = document.getElementById('globe-container');
const panel = document.getElementById('weatherPanel');
const hint = document.getElementById('hint');
const loadingOverlay = document.getElementById('loadingOverlay');

// === Init Globe ===
function initGlobe() {
    const containerRect = container.getBoundingClientRect();
    const width = containerRect.width;
    const height = containerRect.height;

    globe = Globe()
        .globeImageUrl('//unpkg.com/three-globe/example/img/earth-blue-marble.jpg')
        .bumpImageUrl('//unpkg.com/three-globe/example/img/earth-topology.png')
        .backgroundImageUrl('//unpkg.com/three-globe/example/img/night-sky.png')
        .width(width)
        .height(height)
        .backgroundColor('#0a0e1a')
        .atmosphereColor('#3b82f6')
        .atmosphereAltitude(0.25)
        .polygonCapColor(() => 'rgba(255, 255, 255, 0.02)')
        .polygonSideColor(() => 'rgba(255, 255, 255, 0.02)')
        .polygonLabel(({ properties: d }) => `
            <div class="country-label">
                <strong>${d.ADMIN || d.NAME || 'Unknown'}</strong>
            </div>
        `)
        .polygonAltitude(0.005)
        .polygonStrokeColor(() => 'rgba(59, 130, 246, 0.3)')
        .onPolygonHover((polygon) => {
            globe.polygonAltitude((d) => (d === polygon ? 0.02 : 0.005));
            globe.polygonCapColor((d) =>
                d === polygon
                    ? 'rgba(59, 130, 246, 0.25)'
                    : 'rgba(255, 255, 255, 0.02)'
            );
            globe.polygonStrokeColor((d) =>
                d === polygon
                    ? 'rgba(59, 130, 246, 0.8)'
                    : 'rgba(59, 130, 246, 0.3)'
            );
            container.style.cursor = polygon ? 'pointer' : 'default';
        })
        .onPolygonClick(handleCountryClick)
        .polygonsTransitionDuration(300)
        .pointAltitude('alt')
        .pointColor(() => '#06b6d4')
        .pointRadius(0.5)
        .pointLabel(() => '')

    // Attach to container
    globe(container);

    // Auto-rotate
    globe.controls().autoRotate = true;
    globe.controls().autoRotateSpeed = 0.8;

    // Pause auto-rotate on user drag
    globe.controls().addEventListener('start', () => {
        isUserInteracting = true;
        globe.controls().autoRotate = false;
        if (interactionTimeout) clearTimeout(interactionTimeout);
    });
    globe.controls().addEventListener('end', () => {
        interactionTimeout = setTimeout(() => {
            isUserInteracting = false;
            globe.controls().autoRotate = true;
        }, 3000);
    });

    // Load countries
    loadCountries();

    // Handle resize
    window.addEventListener('resize', handleResize);
}

// === Load Countries GeoJSON ===
async function loadCountries() {
    try {
        const resp = await fetch('/api/countries/');
        if (!resp.ok) throw new Error('Failed to load countries');
        const data = await resp.json();

        // Filter: only countries with ADMIN names
        countriesGeoJSON = {
            ...data,
            features: data.features.filter(
                (f) => f.properties && (f.properties.ADMIN || f.properties.NAME)
            ),
        };

        globe.polygonsData(countriesGeoJSON.features);
    } catch (err) {
        console.error('Error loading countries:', err);
    }
}

// === Handle Country Click ===
async function handleCountryClick(polygon) {
    const props = polygon.properties;
    const name = props.ADMIN || props.NAME || 'Unknown';

    // Calculate centroid from polygon geometry
    const centroid = getCentroid(polygon);
    if (!centroid) return;

    // Show loading
    loadingOverlay.classList.add('active');
    document.getElementById('countryName').textContent = name;

    try {
        const resp = await fetch(
            `/api/weather/?lat=${centroid[1]}&lon=${centroid[0]}&country=${encodeURIComponent(name)}`
        );
        if (!resp.ok) throw new Error('Weather fetch failed');
        const data = await resp.json();

        populatePanel(data, name);
        openPanel();
    } catch (err) {
        console.error('Weather error:', err);
        document.getElementById('countryName').textContent = 'Error loading data';
    } finally {
        loadingOverlay.classList.remove('active');
        hint.classList.add('hidden');
    }

    // Fly to country
    globe.pointOfView({ lat: centroid[1], lng: centroid[0], altitude: 1.8 }, 800);
}

// === Calculate Centroid from GeoJSON polygon ===
function getCentroid(feature) {
    if (!feature || !feature.geometry) return null;

    const coords = feature.geometry.coordinates;
    let points = [];

    if (feature.geometry.type === 'Polygon') {
        points = coords[0];
    } else if (feature.geometry.type === 'MultiPolygon') {
        // Use the largest polygon
        let maxArea = 0;
        for (const poly of coords) {
            const area = poly[0].length;
            if (area > maxArea) {
                maxArea = area;
                points = poly[0];
            }
        }
    }

    if (points.length === 0) return null;

    let sumX = 0, sumY = 0, sumZ = 0;
    for (const p of points) {
        const lon = (p[0] * Math.PI) / 180;
        const lat = (p[1] * Math.PI) / 180;
        sumX += Math.cos(lat) * Math.cos(lon);
        sumY += Math.cos(lat) * Math.sin(lon);
        sumZ += Math.sin(lat);
    }
    const n = points.length;
    const avgX = sumX / n;
    const avgY = sumY / n;
    const avgZ = sumZ / n;

    const lon = Math.atan2(avgY, avgX);
    const hyp = Math.sqrt(avgX * avgX + avgY * avgY);
    const lat = Math.atan2(avgZ, hyp);

    return [(lon * 180) / Math.PI, (lat * 180) / Math.PI];
}

// === Populate Weather Panel ===
function populatePanel(data, countryName) {
    const c = data.current || {};
    const daily = data.daily || [];

    document.getElementById('countryName').textContent = countryName;
    document.getElementById('weatherIcon').textContent = c.icon || '☀️';
    document.getElementById('tempValue').textContent = c.temp != null ? Math.round(c.temp) : '--';
    document.getElementById('weatherDesc').textContent = c.weather || '--';

    document.getElementById('feelsLike').textContent =
        c.feels_like != null ? `${Math.round(c.feels_like)}°C` : '--°C';
    document.getElementById('humidity').textContent =
        c.humidity != null ? `${c.humidity}%` : '--%';
    document.getElementById('wind').textContent =
        c.wind_speed != null ? `${Math.round(c.wind_speed)} km/h` : '-- km/h';
    document.getElementById('precip').textContent =
        c.precipitation != null ? `${c.precipitation} mm` : '-- mm';
    document.getElementById('pressure').textContent =
        c.pressure != null ? `${Math.round(c.pressure)} hPa` : '-- hPa';
    document.getElementById('uvIndex').textContent =
        c.uv_index != null ? c.uv_index.toFixed(1) : '--';

    // 7-day forecast
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const forecastList = document.getElementById('forecastList');
    forecastList.innerHTML = '';

    daily.forEach((day) => {
        const date = new Date(day.date + 'T00:00:00');
        const dayName = days[date.getDay()] || day.date;

        const el = document.createElement('div');
        el.className = 'forecast-day';
        el.innerHTML = `
            <span class="day-name">${dayName}</span>
            <span class="day-icon">${day.icon || '☀️'}</span>
            <span class="day-temps">
                <span class="high">${day.temp_max != null ? Math.round(day.temp_max) : '--'}°</span>
                <span class="low">${day.temp_min != null ? Math.round(day.temp_min) : '--'}°</span>
            </span>
            <span class="day-precip">${day.precip != null ? `${day.precip} mm` : ''}</span>
        `;
        forecastList.appendChild(el);
    });
}

// === Panel Open/Close ===
function openPanel() {
    panel.classList.add('open');
}
function closePanel() {
    panel.classList.remove('open');
}
window.closePanel = closePanel;

// === Resize Handler ===
function handleResize() {
    if (!globe) return;
    const rect = container.getBoundingClientRect();
    globe.width(rect.width);
    globe.height(rect.height);
}

// === Keyboard: Escape closes panel ===
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closePanel();
});

// === Start ===
document.addEventListener('DOMContentLoaded', initGlobe);