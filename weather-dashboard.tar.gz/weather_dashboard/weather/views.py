import urllib.request
import json
from django.http import JsonResponse
from django.views import View
from django.shortcuts import render
from django.conf import settings

# WMO Weather Codes → Description mapping
WMO_CODES = {
    0: ("Clear", "☀️"),
    1: ("Mainly Clear", "🌤️"),
    2: ("Partly Cloudy", "⛅"),
    3: ("Overcast", "☁️"),
    45: ("Foggy", "🌫️"),
    48: ("Depositing Rime Fog", "🌫️"),
    51: ("Light Drizzle", "🌦️"),
    53: ("Moderate Drizzle", "🌦️"),
    55: ("Dense Drizzle", "🌧️"),
    56: ("Light Freezing Drizzle", "🌧️"),
    57: ("Dense Freezing Drizzle", "🌧️"),
    61: ("Slight Rain", "🌦️"),
    63: ("Moderate Rain", "🌧️"),
    65: ("Heavy Rain", "🌧️"),
    66: ("Light Freezing Rain", "🌧️"),
    67: ("Heavy Freezing Rain", "🌧️"),
    71: ("Slight Snow", "🌨️"),
    73: ("Moderate Snow", "🌨️"),
    75: ("Heavy Snow", "❄️"),
    77: ("Snow Grains", "❄️"),
    80: ("Slight Rain Showers", "🌦️"),
    81: ("Moderate Rain Showers", "🌧️"),
    82: ("Violent Rain Showers", "🌧️"),
    85: ("Slight Snow Showers", "🌨️"),
    86: ("Heavy Snow Showers", "🌨️"),
    95: ("Thunderstorm", "⛈️"),
    96: ("Thunderstorm with Slight Hail", "⛈️"),
    99: ("Thunderstorm with Heavy Hail", "⛈️"),
}

class CountryWeatherView(View):
    """Get country boundaries and weather for a clicked country."""

    def get(self, request):
        lat = request.GET.get('lat')
        lon = request.GET.get('lon')
        country = request.GET.get('country', 'Unknown')

        if not lat or not lon:
            return JsonResponse({'error': 'lat and lon required'}, status=400)

        try:
            url = (
                f"https://api.open-meteo.com/v1/forecast?"
                f"latitude={lat}&longitude={lon}"
                f"&current=temperature_2m,relative_humidity_2m,apparent_temperature,"
                f"precipitation,weather_code,wind_speed_10m,pressure_msl,uv_index"
                f"&daily=temperature_2m_max,temperature_2m_min,weather_code,"
                f"precipitation_sum,wind_speed_10m_max&timezone=auto"
            )
            req = urllib.request.Request(url, headers={'User-Agent': 'WeatherGlobe/1.0'})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())

            weather_code = data.get('current', {}).get('weather_code', 0)
            wmo = WMO_CODES.get(weather_code, ("Unknown", "❓"))
            current = data.get('current', {})
            daily = data.get('daily', {})

            result = {
                'country': country,
                'latitude': lat,
                'longitude': lon,
                'current': {
                    'temp': current.get('temperature_2m'),
                    'feels_like': current.get('apparent_temperature'),
                    'humidity': current.get('relative_humidity_2m'),
                    'precipitation': current.get('precipitation'),
                    'wind_speed': current.get('wind_speed_10m'),
                    'pressure': current.get('pressure_msl'),
                    'uv_index': current.get('uv_index'),
                    'weather': wmo[0],
                    'icon': wmo[1],
                    'code': weather_code,
                },
                'daily': [
                    {
                        'date': daily.get('time', [])[i] if i < len(daily.get('time', [])) else '',
                        'temp_max': daily.get('temperature_2m_max', [])[i] if i < len(daily.get('temperature_2m_max', [])) else '',
                        'temp_min': daily.get('temperature_2m_min', [])[i] if i < len(daily.get('temperature_2m_min', [])) else '',
                        'weather': WMO_CODES.get(
                            daily.get('weather_code', [])[i] if i < len(daily.get('weather_code', [])) else 0,
                            ("", "")
                        )[0],
                        'icon': WMO_CODES.get(
                            daily.get('weather_code', [])[i] if i < len(daily.get('weather_code', [])) else 0,
                            ("", "")
                        )[1],
                        'precip': daily.get('precipitation_sum', [])[i] if i < len(daily.get('precipitation_sum', [])) else '',
                        'wind': daily.get('wind_speed_10m_max', [])[i] if i < len(daily.get('wind_speed_10m_max', [])) else '',
                    }
                    for i in range(min(7, len(daily.get('time', []))))
                ]
            }
            return JsonResponse(result)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class CountriesGeoJSONView(View):
    """Proxy for world countries GeoJSON."""

    def get(self, request):
        try:
            url = (
                "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/"
                "master/geojson/ne_110m_admin_0_countries.geojson"
            )
            req = urllib.request.Request(url, headers={'User-Agent': 'WeatherGlobe/1.0'})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())
            return JsonResponse(data, safe=False)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)


class IndexView(View):
    """Serve the main page."""
    def get(self, request):
        return render(request, 'core/index.html')