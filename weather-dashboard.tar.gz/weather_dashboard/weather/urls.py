from django.urls import path
from .views import CountryWeatherView, CountriesGeoJSONView

urlpatterns = [
    path('weather/', CountryWeatherView.as_view(), name='weather'),
    path('countries/', CountriesGeoJSONView.as_view(), name='countries'),
]