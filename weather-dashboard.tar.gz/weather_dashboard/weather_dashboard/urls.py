from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from weather.views import IndexView

urlpatterns = [
    path('api/', include('weather.urls')),
    path('', IndexView.as_view(), name='index'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)