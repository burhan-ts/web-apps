import json, urllib.request, urllib.parse, urllib.error, ssl
from pathlib import Path
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import xml.etree.ElementTree as ET
import html

BASE_DIR = Path(__file__).resolve().parent.parent

# 55 major world cities
CITIES = [
    {"city": "New York", "country": "USA", "lat": 40.7128, "lng": -74.006, "size": 3},
    {"city": "Los Angeles", "country": "USA", "lat": 34.0522, "lng": -118.2437, "size": 2.5},
    {"city": "Washington DC", "country": "USA", "lat": 38.9072, "lng": -77.0369, "size": 2},
    {"city": "Toronto", "country": "Canada", "lat": 43.6532, "lng": -79.3832, "size": 2.5},
    {"city": "Mexico City", "country": "Mexico", "lat": 19.4326, "lng": -99.1332, "size": 2.5},
    {"city": "Havana", "country": "Cuba", "lat": 23.1136, "lng": -82.3666, "size": 1.5},
    {"city": "São Paulo", "country": "Brazil", "lat": -23.5505, "lng": -46.6333, "size": 3},
    {"city": "Buenos Aires", "country": "Argentina", "lat": -34.6037, "lng": -58.3816, "size": 2.5},
    {"city": "Lima", "country": "Peru", "lat": -12.0464, "lng": -77.0428, "size": 2},
    {"city": "Bogotá", "country": "Colombia", "lat": 4.7110, "lng": -74.0721, "size": 2},
    {"city": "Santiago", "country": "Chile", "lat": -33.4489, "lng": -70.6693, "size": 2},
    {"city": "Rio de Janeiro", "country": "Brazil", "lat": -22.9068, "lng": -43.1729, "size": 2},
    {"city": "London", "country": "UK", "lat": 51.5074, "lng": -0.1278, "size": 3},
    {"city": "Paris", "country": "France", "lat": 48.8566, "lng": 2.3522, "size": 3},
    {"city": "Berlin", "country": "Germany", "lat": 52.5200, "lng": 13.4050, "size": 2.5},
    {"city": "Rome", "country": "Italy", "lat": 41.9028, "lng": 12.4964, "size": 2.5},
    {"city": "Madrid", "country": "Spain", "lat": 40.4168, "lng": -3.7038, "size": 2.5},
    {"city": "Moscow", "country": "Russia", "lat": 55.7558, "lng": 37.6173, "size": 3},
    {"city": "Amsterdam", "country": "Netherlands", "lat": 52.3676, "lng": 4.9041, "size": 2},
    {"city": "Stockholm", "country": "Sweden", "lat": 59.3293, "lng": 18.0686, "size": 2},
    {"city": "Athens", "country": "Greece", "lat": 37.9838, "lng": 23.7275, "size": 2},
    {"city": "Kyiv", "country": "Ukraine", "lat": 50.4501, "lng": 30.5234, "size": 2.5},
    {"city": "Istanbul", "country": "Turkey", "lat": 41.0082, "lng": 28.9784, "size": 2.5},
    {"city": "Cairo", "country": "Egypt", "lat": 30.0444, "lng": 31.2357, "size": 3},
    {"city": "Lagos", "country": "Nigeria", "lat": 6.5244, "lng": 3.3792, "size": 3},
    {"city": "Johannesburg", "country": "South Africa", "lat": -26.2041, "lng": 28.0473, "size": 2.5},
    {"city": "Nairobi", "country": "Kenya", "lat": -1.2921, "lng": 36.8219, "size": 2.5},
    {"city": "Casablanca", "country": "Morocco", "lat": 33.5731, "lng": -7.5898, "size": 2},
    {"city": "Addis Ababa", "country": "Ethiopia", "lat": 9.0320, "lng": 38.7469, "size": 2},
    {"city": "Accra", "country": "Ghana", "lat": 5.6037, "lng": -0.1870, "size": 2},
    {"city": "Tokyo", "country": "Japan", "lat": 35.6762, "lng": 139.6503, "size": 3.5},
    {"city": "Beijing", "country": "China", "lat": 39.9042, "lng": 116.4074, "size": 3},
    {"city": "Shanghai", "country": "China", "lat": 31.2304, "lng": 121.4737, "size": 2.5},
    {"city": "Delhi", "country": "India", "lat": 28.7041, "lng": 77.1025, "size": 3},
    {"city": "Mumbai", "country": "India", "lat": 19.0760, "lng": 72.8777, "size": 3},
    {"city": "Seoul", "country": "South Korea", "lat": 37.5665, "lng": 126.9780, "size": 2.5},
    {"city": "Bangkok", "country": "Thailand", "lat": 13.7563, "lng": 100.5018, "size": 2.5},
    {"city": "Singapore", "country": "Singapore", "lat": 1.3521, "lng": 103.8198, "size": 2.5},
    {"city": "Dubai", "country": "UAE", "lat": 25.2048, "lng": 55.2708, "size": 2.5},
    {"city": "Taipei", "country": "Taiwan", "lat": 25.0330, "lng": 121.5654, "size": 2},
    {"city": "Hong Kong", "country": "China", "lat": 22.3193, "lng": 114.1694, "size": 2.5},
    {"city": "Jakarta", "country": "Indonesia", "lat": -6.2088, "lng": 106.8456, "size": 3},
    {"city": "Manila", "country": "Philippines", "lat": 14.5995, "lng": 120.9842, "size": 2.5},
    {"city": "Sydney", "country": "Australia", "lat": -33.8688, "lng": 151.2093, "size": 2.5},
    {"city": "Melbourne", "country": "Australia", "lat": -37.8136, "lng": 144.9631, "size": 2},
    {"city": "Auckland", "country": "New Zealand", "lat": -36.8485, "lng": 174.7633, "size": 2},
    {"city": "Tel Aviv", "country": "Israel", "lat": 32.0853, "lng": 34.7818, "size": 2},
    {"city": "Riyadh", "country": "Saudi Arabia", "lat": 24.7136, "lng": 46.6753, "size": 2.5},
    {"city": "Tehran", "country": "Iran", "lat": 35.6892, "lng": 51.3890, "size": 2.5},
    {"city": "Doha", "country": "Qatar", "lat": 25.2854, "lng": 51.5310, "size": 1.5},
    {"city": "Oslo", "country": "Norway", "lat": 59.9139, "lng": 10.7522, "size": 2},
    {"city": "Zurich", "country": "Switzerland", "lat": 47.3769, "lng": 8.5417, "size": 2},
    {"city": "Lisbon", "country": "Portugal", "lat": 38.7223, "lng": -9.1393, "size": 2},
    {"city": "Prague", "country": "Czech Republic", "lat": 50.0755, "lng": 14.4378, "size": 2},
    {"city": "Helsinki", "country": "Finland", "lat": 60.1699, "lng": 24.9384, "size": 2},
    {"city": "Dublin", "country": "Ireland", "lat": 53.3498, "lng": -6.2603, "size": 2},
    {"city": "Warsaw", "country": "Poland", "lat": 52.2297, "lng": 21.0122, "size": 2},
]

# Google News RSS country codes
COUNTRY_CODES = {
    "USA": "US", "Canada": "CA", "Mexico": "MX", "Cuba": "CU",
    "Brazil": "BR", "Argentina": "AR", "Peru": "PE", "Colombia": "CO",
    "Chile": "CL",
    "UK": "GB", "France": "FR", "Germany": "DE", "Italy": "IT",
    "Spain": "ES", "Russia": "RU", "Netherlands": "NL", "Sweden": "SE",
    "Greece": "GR", "Ukraine": "UA", "Turkey": "TR",
    "Egypt": "EG", "Nigeria": "NG", "South Africa": "ZA", "Kenya": "KE",
    "Morocco": "MA", "Ethiopia": "ET", "Ghana": "GH",
    "Japan": "JP", "China": "CN", "India": "IN", "South Korea": "KR",
    "Thailand": "TH", "Singapore": "SG", "UAE": "AE", "Taiwan": "TW",
    "Indonesia": "ID", "Philippines": "PH",
    "Australia": "AU", "New Zealand": "NZ",
    "Israel": "IL", "Saudi Arabia": "SA", "Iran": "IR", "Qatar": "QA",
    "Norway": "NO", "Switzerland": "CH", "Portugal": "PT",
    "Czech Republic": "CZ", "Finland": "FI", "Ireland": "IE", "Poland": "PL",
}


def index(request):
    return render(request, 'core/index.html')


def cities(request):
    return JsonResponse(CITIES, safe=False)


@csrf_exempt
def news(request, city, country):
    try:
        articles = []

        # Source 1: Google News RSS (free, no API key)
        cc = COUNTRY_CODES.get(country, "")
        rss_urls = [
            f"https://news.google.com/rss/search?q={urllib.parse.quote(city)}+{urllib.parse.quote(country)}&hl=en-US&gl={cc}&ceid=US:en",
            f"https://news.google.com/rss/search?q={urllib.parse.quote(city)}&hl=en-US&gl=US&ceid=US:en",
        ]

        for rss_url in rss_urls:
            try:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                req = urllib.request.Request(rss_url, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })
                resp = urllib.request.urlopen(req, timeout=8, context=ctx)
                xml_data = resp.read().decode('utf-8', errors='replace')

                root = ET.fromstring(xml_data)
                ns = {'atom': 'http://www.w3.org/2005/Atom',
                      'media': 'http://search.yahoo.com/mrss/'}

                for item in root.iter('item'):
                    title = item.findtext('title', '')
                    desc = item.findtext('description', '')
                    link = item.findtext('link', '')
                    pubDate = item.findtext('pubDate', '')
                    source = item.findtext('source', '')

                    # Clean HTML from desc
                    desc = html.unescape(desc or '')
                    # Strip basic tags
                    import re
                    desc = re.sub(r'<[^>]+>', '', desc)
                    if len(desc) > 200:
                        desc = desc[:200] + '...'

                    articles.append({
                        'title': title,
                        'description': desc or 'Latest news from ' + city,
                        'url': link,
                        'source': source or 'Google News',
                        'image': '',
                        'published': pubDate[:10] if pubDate else '',
                    })

                    if len(articles) >= 12:
                        break

                if articles:
                    break
            except Exception:
                continue

        # Source 2: Wikipedia current events (fallback)
        if not articles:
            try:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                wiki_url = "https://en.wikipedia.org/api/rest_v1/feed/news"
                req = urllib.request.Request(wiki_url, headers={
                    'User-Agent': 'NewsGlobe/1.0 (news-app)'
                })
                resp = urllib.request.urlopen(req, timeout=8, context=ctx)
                wiki_data = json.loads(resp.read().decode())
                for item in wiki_data.get('news', [])[:8]:
                    story = item.get('story', '')
                    links = item.get('links', [])
                    url_link = links[0].get('url', '') if links else ''
                    articles.append({
                        'title': story[:120] + ('...' if len(story) > 120 else ''),
                        'description': f'Wikipedia — related to {city}',
                        'url': f"https://en.wikipedia.org{url_link}" if url_link else '',
                        'source': 'Wikipedia',
                        'image': '',
                        'published': '',
                    })
            except Exception:
                pass

        return JsonResponse({'articles': articles, 'count': len(articles)})

    except Exception as e:
        return JsonResponse({'articles': [], 'error': str(e)})


def borders(request):
    return JsonResponse({'count': 0, 'message': 'Borders loaded client-side'})