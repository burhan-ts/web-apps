from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('api/cities/', views.cities, name='cities'),
    path('api/news/<str:city>/<str:country>/', views.news, name='news'),
    path('api/borders/', views.borders, name='borders'),
]