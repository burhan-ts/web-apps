/* global THREE, fetch */
(function() {
    'use strict';

    // --- Setup ---
    const container = document.getElementById('globe-container');
    const loading = document.getElementById('loading');
    const tooltip = document.getElementById('tooltip');
    const newsPanel = document.getElementById('news-panel');
    const articlesDiv = document.getElementById('articles');
    const panelCity = document.getElementById('panel-city');
    const panelCountry = document.getElementById('panel-country');
    const closeBtn = document.getElementById('close-btn');
    const toast = document.getElementById('toast');
    const newsLoading = document.getElementById('news-loading');

    let scene, camera, renderer, globe, atmosphere;
    let mouse = new THREE.Vector2(), raycaster = new THREE.Raycaster();
    let isDragging = false, isInteracting = false, autoRotate = true;
    let mouseDownPos = { x: 0, y: 0 };
    let hoveredCity = null;
    let cityMeshes = [];
    let cityData = [];
    let bordersLines = [];
    let flyAnim = null;
    let interactionTimeout = null;
    let globeRadius = 5;
    let animationId = null;

    // --- Init ---
    function init() {
        scene = new THREE.Scene();

        camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 2, 14);
        camera.lookAt(0, 0, 0);

        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.setClearColor(0x0a0a1a, 1);
        container.appendChild(renderer.domElement);

        // Lights
        const ambient = new THREE.AmbientLight(0x404060, 0.6);
        scene.add(ambient);
        const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
        dirLight.position.set(5, 10, 7);
        scene.add(dirLight);
        const fillLight = new THREE.DirectionalLight(0x4488ff, 0.3);
        fillLight.position.set(-5, -3, -5);
        scene.add(fillLight);

        // Stars
        createStars();

        // Globe
        createGlobe();

        // Atmosphere glow
        createAtmosphere();

        // Load borders
        loadBorders();

        // Load cities
        loadCities();

        // Events
        setupEvents();

        // Start
        animate();
    }

    // --- Stars ---
    function createStars() {
        const starsGeo = new THREE.BufferGeometry();
        const starsCount = 6000;
        const pos = new Float32Array(starsCount * 3);
        const sizes = new Float32Array(starsCount);
        for (let i = 0; i < starsCount; i++) {
            const theta = Math.random() * Math.PI * 2;
            const phi = Math.acos(2 * Math.random() - 1);
            const r = 150 + Math.random() * 100;
            pos[i*3] = r * Math.sin(phi) * Math.cos(theta);
            pos[i*3+1] = r * Math.sin(phi) * Math.sin(theta);
            pos[i*3+2] = r * Math.cos(phi);
            sizes[i] = 0.5 + Math.random() * 1.5;
        }
        starsGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        starsGeo.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
        const starMat = new THREE.PointsMaterial({
            color: 0xffffff, size: 0.3, transparent: true, opacity: 0.8,
            blending: THREE.AdditiveBlending
        });
        const stars = new THREE.Points(starsGeo, starMat);
        scene.add(stars);
    }

    // --- Globe ---
    function createGlobe() {
        const geo = new THREE.SphereGeometry(globeRadius, 64, 64);

        const textureLoader = new THREE.TextureLoader();
        const earthTex = textureLoader.load('/static/img/earth.jpg');

        const mat = new THREE.MeshPhongMaterial({
            map: earthTex,
            specular: new THREE.Color(0x222244),
            shininess: 25,
        });
        globe = new THREE.Mesh(geo, mat);
        globe.rotation.x = 0.1;
        scene.add(globe);
    }

    function createAtmosphere() {
        const geo = new THREE.SphereGeometry(globeRadius * 1.015, 64, 64);
        const mat = new THREE.MeshPhongMaterial({
            color: 0x4488ff,
            transparent: true,
            opacity: 0.08,
            side: THREE.BackSide,
        });
        atmosphere = new THREE.Mesh(geo, mat);
        scene.add(atmosphere);
    }

    // --- Country Borders ---
    function loadBorders() {
        fetch('/static/json/countries-110m.json')
            .then(r => r.json())
            .then(data => {
                const features = data.features || [];
                const borderMat = new THREE.LineBasicMaterial({
                    color: 0x4488ff,
                    transparent: true,
                    opacity: 0.25,
                });

                features.forEach(feature => {
                    const coords = extractCoords(feature);
                    coords.forEach(ring => {
                        if (ring.length < 3) return;
                        const positions = ring.map(([lng, lat]) => {
                            const phi = (90 - lat) * Math.PI / 180;
                            const theta = (lng + 180) * Math.PI / 180;
                            const r = globeRadius * 1.002;
                            return new THREE.Vector3(
                                -r * Math.sin(phi) * Math.cos(theta),
                                r * Math.cos(phi),
                                r * Math.sin(phi) * Math.sin(theta)
                            );
                        });
                        const geo = new THREE.BufferGeometry().setFromPoints(positions);
                        const line = new THREE.Line(geo, borderMat);
                        globe.add(line);
                        bordersLines.push(line);
                    });
                });
            })
            .catch(() => {});
    }

    function extractCoords(feature) {
        const coords = [];
        const geom = feature.geometry;
        if (!geom) return coords;
        if (geom.type === 'Polygon') {
            geom.coordinates.forEach(ring => coords.push(ring));
        } else if (geom.type === 'MultiPolygon') {
            geom.coordinates.forEach(poly => {
                poly.forEach(ring => coords.push(ring));
            });
        }
        return coords;
    }

    // --- Cities ---
    function loadCities() {
        fetch('/api/cities/')
            .then(r => r.json())
            .then(data => {
                cityData = data;
                createCityDots();
                loading.classList.add('hidden');
            })
            .catch(() => {
                loading.classList.add('hidden');
            });
    }

    function createCityDots() {
        cityMeshes.forEach(m => { globe.remove(m); });
        cityMeshes = [];

        cityData.forEach(c => {
            const lat = c.lat, lng = c.lng;
            const phi = (90 - lat) * Math.PI / 180;
            const theta = (lng + 180) * Math.PI / 180;
            const r = globeRadius * 1.01;

            const pos = new THREE.Vector3(
                -r * Math.sin(phi) * Math.cos(theta),
                r * Math.cos(phi),
                r * Math.sin(phi) * Math.sin(theta)
            );

            // Dot
            const dotSize = 0.06 + (c.size || 2) * 0.03;
            const dotGeo = new THREE.SphereGeometry(dotSize, 12, 12);
            const dotMat = new THREE.MeshBasicMaterial({ color: 0x64b4ff });
            const dot = new THREE.Mesh(dotGeo, dotMat);
            dot.position.copy(pos);
            dot.userData = { city: c, isCity: true };
            globe.add(dot);
            cityMeshes.push(dot);

            // Glow ring
            const ringGeo = new THREE.RingGeometry(dotSize * 1.5, dotSize * 2.5, 24);
            const ringMat = new THREE.MeshBasicMaterial({
                color: 0x64b4ff,
                transparent: true,
                opacity: 0.3,
                side: THREE.DoubleSide,
                depthWrite: false,
            });
            const ring = new THREE.Mesh(ringGeo, ringMat);
            ring.position.copy(pos);
            ring.lookAt(0, 0, 0);
            ring.userData = { parent: dot, phase: Math.random() * Math.PI * 2 };
            globe.add(ring);
            cityMeshes.push(ring);

            // Outer glow
            const glowGeo = new THREE.SpriteMaterial({
                map: createGlowTexture(),
                blending: THREE.AdditiveBlending,
                transparent: true,
                opacity: 0.4,
                depthWrite: false,
            });
            const glow = new THREE.Sprite(glowGeo);
            glow.position.copy(pos);
            glow.scale.set(0.8, 0.8, 1);
            glow.userData = { parent: dot, phase: Math.random() * Math.PI * 2 + 2 };
            globe.add(glow);
            cityMeshes.push(glow);
        });
    }

    let glowCanvas = null;
    function createGlowTexture() {
        if (glowCanvas) return glowCanvas;
        const canvas = document.createElement('canvas');
        canvas.width = 64; canvas.height = 64;
        const ctx = canvas.getContext('2d');
        const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
        grad.addColorStop(0, 'rgba(100, 180, 255, 0.6)');
        grad.addColorStop(0.3, 'rgba(100, 180, 255, 0.2)');
        grad.addColorStop(1, 'rgba(100, 180, 255, 0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 64, 64);
        glowCanvas = new THREE.CanvasTexture(canvas);
        return glowCanvas;
    }

    // --- Fly to city ---
    function flyToCity(city) {
        if (flyAnim) { cancelAnimationFrame(flyAnim); flyAnim = null; }

        const lat = city.lat, lng = city.lng;
        const phi = (90 - lat) * Math.PI / 180;
        const theta = (lng + 180) * Math.PI / 180;

        const targetPos = new THREE.Vector3(
            -12 * Math.sin(phi) * Math.cos(theta),
            12 * Math.cos(phi) + 1,
            12 * Math.sin(phi) * Math.sin(theta)
        );

        const startPos = camera.position.clone();
        const startTarget = new THREE.Vector3(0, 0, 0);
        const duration = 1200;
        const startTime = Date.now();

        autoRotate = false;
        isInteracting = true;

        function fly() {
            const elapsed = Date.now() - startTime;
            const t = Math.min(elapsed / duration, 1);
            const ease = 1 - Math.pow(1 - t, 3); // easeOutCubic

            camera.position.lerpVectors(startPos, targetPos, ease);
            camera.lookAt(0, 0, 0);

            if (t < 1) {
                flyAnim = requestAnimationFrame(fly);
            } else {
                flyAnim = null;
                openNewsPanel(city);
                setTimeout(() => {
                    if (!isDragging) {
                        autoRotate = true;
                        isInteracting = false;
                    }
                }, 4000);
            }
        }
        fly();
    }

    // --- News Panel ---
    function openNewsPanel(city) {
        panelCity.textContent = city.city;
        panelCountry.textContent = city.country;
        articlesDiv.innerHTML = '';
        newsLoading.style.display = 'block';
        newsPanel.classList.add('open');

        const cityName = encodeURIComponent(city.city);
        const countryName = encodeURIComponent(city.country);

        fetch(`/api/news/${cityName}/${countryName}/`)
            .then(r => r.json())
            .then(data => {
                newsLoading.style.display = 'none';
                const articles = data.articles || [];
                if (articles.length === 0) {
                    articlesDiv.innerHTML = `
                        <div class="no-news">
                            <div class="icon">📭</div>
                            <p>No news found for ${city.city}</p>
                        </div>`;
                    return;
                }
                articlesDiv.innerHTML = articles.map(a => `
                    <div class="article-card" onclick="window.open('${a.url.replace(/'/g, "\\'")}','_blank')">
                        ${a.image ? `<img class="thumb" src="${a.image}" alt="" onerror="this.style.display='none'">` : ''}
                        <div class="source">${a.source || 'News'}</div>
                        <div class="title">${a.title || 'Untitled'}</div>
                        ${a.description ? `<div class="desc">${a.description}</div>` : ''}
                        <div class="meta">
                            <span>${a.published || ''}</span>
                            <span>↗ Open</span>
                        </div>
                    </div>
                `).join('');
            })
            .catch(() => {
                newsLoading.style.display = 'none';
                articlesDiv.innerHTML = `
                    <div class="no-news">
                        <div class="icon">⚠️</div>
                        <p>Failed to load news. Try again.</p>
                    </div>`;
            });
    }

    function showToast(msg) {
        toast.textContent = msg;
        toast.classList.add('show');
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => toast.classList.remove('show'), 2500);
    }

    // --- Events ---
    function setupEvents() {
        const canvas = renderer.domElement;

        canvas.addEventListener('mousedown', e => {
            mouseDownPos.x = e.clientX;
            mouseDownPos.y = e.clientY;
            isDragging = false;
        });

        canvas.addEventListener('mousemove', e => {
            mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
            mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;

            if (e.buttons === 1) {
                const dx = e.clientX - mouseDownPos.x;
                const dy = e.clientY - mouseDownPos.y;
                if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
                    isDragging = true;
                    if (autoRotate) {
                        autoRotate = false;
                        isInteracting = true;
                    }
                    clearTimeout(interactionTimeout);
                    interactionTimeout = setTimeout(() => {
                        if (!isDragging) return;
                        autoRotate = true;
                        isInteracting = false;
                    }, 4000);
                }
                // Rotate globe
                if (isDragging) {
                    const deltaX = dx * 0.005;
                    const deltaY = dy * 0.003;
                    globe.rotation.y += deltaX;
                    const rotX = globe.rotation.x + deltaY;
                    globe.rotation.x = Math.max(-0.5, Math.min(0.8, rotX));
                    mouseDownPos.x = e.clientX;
                    mouseDownPos.y = e.clientY;
                }
            }

            // Hover detection
            raycaster.setFromCamera(mouse, camera);
            const intersects = raycaster.intersectObjects(cityMeshes);
            let found = null;
            for (const hit of intersects) {
                if (hit.object.userData && hit.object.userData.isCity) {
                    found = hit.object.userData.city;
                    break;
                }
                if (hit.object.userData && hit.object.userData.parent) {
                    const p = hit.object.userData.parent;
                    if (p.userData && p.userData.city) {
                        found = p.userData.city;
                        break;
                    }
                }
            }

            if (found) {
                canvas.style.cursor = 'pointer';
                tooltip.style.display = 'block';
                tooltip.querySelector('.city-name').textContent = found.city;
                tooltip.querySelector('.city-country').textContent = found.country;
                tooltip.style.left = (e.clientX + 15) + 'px';
                tooltip.style.top = (e.clientY - 10) + 'px';
                hoveredCity = found;
            } else {
                canvas.style.cursor = 'grab';
                tooltip.style.display = 'none';
                hoveredCity = null;
            }
        });

        canvas.addEventListener('mouseup', e => {
            const dx = e.clientX - mouseDownPos.x;
            const dy = e.clientY - mouseDownPos.y;
            if (Math.abs(dx) < 5 && Math.abs(dy) < 5) {
                // It was a click
                raycaster.setFromCamera(mouse, camera);
                const intersects = raycaster.intersectObjects(cityMeshes);
                for (const hit of intersects) {
                    let city = null;
                    if (hit.object.userData && hit.object.userData.isCity) {
                        city = hit.object.userData.city;
                    } else if (hit.object.userData && hit.object.userData.parent) {
                        const p = hit.object.userData.parent;
                        if (p.userData && p.userData.city) city = p.userData.city;
                    }
                    if (city) {
                        flyToCity(city);
                        break;
                    }
                }
            }
            isDragging = false;
        });

        // Touch support
        let touchStartPos = { x: 0, y: 0 }, touchMoved = false;
        canvas.addEventListener('touchstart', e => {
            const t = e.touches[0];
            touchStartPos.x = t.clientX;
            touchStartPos.y = t.clientY;
            touchMoved = false;
            if (autoRotate) {
                autoRotate = false;
                isInteracting = true;
            }
            clearTimeout(interactionTimeout);
        }, { passive: true });

        canvas.addEventListener('touchmove', e => {
            const t = e.touches[0];
            const dx = t.clientX - touchStartPos.x;
            const dy = t.clientY - touchStartPos.y;
            if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                touchMoved = true;
                globe.rotation.y += dx * 0.005;
                const rotX = globe.rotation.x + dy * 0.003;
                globe.rotation.x = Math.max(-0.5, Math.min(0.8, rotX));
                touchStartPos.x = t.clientX;
                touchStartPos.y = t.clientY;
            }
        }, { passive: true });

        canvas.addEventListener('touchend', e => {
            if (!touchMoved) {
                // Tap - find nearest city
                const t = e.changedTouches[0];
                // Project touch to city detection
                const vx = (t.clientX / window.innerWidth) * 2 - 1;
                const vy = -(t.clientY / window.innerHeight) * 2 + 1;
                const tempMouse = new THREE.Vector2(vx, vy);
                raycaster.setFromCamera(tempMouse, camera);
                const intersects = raycaster.intersectObjects(cityMeshes);
                for (const hit of intersects) {
                    let city = null;
                    if (hit.object.userData && hit.object.userData.isCity) {
                        city = hit.object.userData.city;
                    } else if (hit.object.userData && hit.object.userData.parent) {
                        const p = hit.object.userData.parent;
                        if (p.userData && p.userData.city) city = p.userData.city;
                    }
                    if (city) {
                        flyToCity(city);
                        break;
                    }
                }
            }
            interactionTimeout = setTimeout(() => {
                autoRotate = true;
                isInteracting = false;
            }, 4000);
        }, { passive: true });

        // Close panel
        closeBtn.addEventListener('click', () => {
            newsPanel.classList.remove('open');
        });

        // Keyboard
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') newsPanel.classList.remove('open');
        });

        // Resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }

    // --- Animation Loop ---
    let time = 0;
    function animate() {
        animationId = requestAnimationFrame(animate);
        time += 0.005;

        // Auto-rotation
        if (autoRotate && !isDragging) {
            globe.rotation.y += 0.001;
        }

        // Animate glow rings
        cityMeshes.forEach(m => {
            if (m.isRing || (m.material && m.material.type === 'SpriteMaterial')) {
                // Pulse opacity
                const phase = m.userData.phase || 0;
                const pulse = 0.3 + 0.2 * Math.sin(time * 2 + phase);
                if (m.material) m.material.opacity = pulse;
            }
        });

        // Animate atmosphere
        if (atmosphere) {
            atmosphere.rotation.y += 0.0005;
        }

        renderer.render(scene, camera);
    }

    // --- Start ---
    if (container) {
        init();
    }
})();